#############################################KEYS################################################
Esc: Exit
Q: Zoom in
E: Zoom out
W: Move down
S: Move up
A: Move right
D: Move left
Z: Rotate right
X: Rotate left
R: Increment convolution mode
F: Decrement convolution mode
T: Increment colour mode
G: Decrement colour mode
1: Prior Image
2: Next Image
############################### Frag modes ########################
0: None
1: Horizontal Sobel Edge
2: Vertical Sobel Edge
3: Merged Sobel Edge
4: Unsharp
5+: Gaussian Blur
############################## B/W modes #################
0 : None
1 : L1
2 : L2
3 : L3
4 : Sepia
OpenGL [ 4.1.0 NVIDIA 367.44 ] with GLSL [ 4.10 NVIDIA via Cg compiler ] on renderer [ GeForce GTX 745/PCIe/SSE2 ]
3
